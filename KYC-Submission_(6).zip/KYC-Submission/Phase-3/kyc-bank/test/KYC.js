const { expect } =  require("chai");
// const { Contract } = require("ethers");
const { ethers } = require("hardhat");
// var KYC = artifacts.require("./KYC.sol");

describe("KYC",function(){

    // do initial test
    it("Initially Bank count Should be 0", async function (){
        const Contract = await ethers.getContractFactory("KYC");
        const contract = await Contract.deploy();
        await contract.deployed();

        expect(await contract.getBanksCount()).to.equal(0);

    });

    //  create a new bank 
    it("Should create a new Bank", async function(){
        const Contract = await ethers.getContractFactory("KYC");
        const contract = await Contract.deploy();
        await contract.deployed();
        
        const addBankTx = await contract.addBank("main bank","0xf39fd6e51aad88f6f4ce6ab8827279cfffb92266","1");
        console.log("Adding Bank");
        await addBankTx.wait();

        expect(await contract.getBanksCount()).to.equal(1);
    });

    // Initial test for Customer count it Should be 0
    it("Initially Customer count Should be 0", async function (){
        const Contract = await ethers.getContractFactory("KYC");
        const contract = await Contract.deploy();
        await contract.deployed();

        expect(await contract.getBanksCount()).to.equal(0);

    });    


    it("Should create a new Customer", async function(){
        const Contract = await ethers.getContractFactory("KYC");
        const contract = await Contract.deploy();
        await contract.deployed();
        
        const addBankTx = await contract.addBank("main bank","0xf39fd6e51aad88f6f4ce6ab8827279cfffb92266","1");
        console.log("Adding Bank");
        await addBankTx.wait(); 
        expect(await contract.getBanksCount()).to.equal(1);

        const addCustomerTx = await contract.addCustomer("Ram","Ram's data is here");
        console.log("Adding Customer");
        await addCustomerTx.wait();

        expect(await contract.getCustomersCount()).to.equal(1);

        
    });



    it("Should create a new banks,customers,and upvote and downvote them", async function(){
        const Contract = await ethers.getContractFactory("KYC");
        const contract = await Contract.deploy();
        await contract.deployed();
        
        // Add a bank named main Bank
        const addBankTx = await contract.addBank("main bank","0xf39fd6e51aad88f6f4ce6ab8827279cfffb92266","1");
        console.log("Adding Bank 1");
        await addBankTx.wait(); 

        expect(await contract.getBanksCount()).to.equal(1);

        // Add a bank named SBI Bank
        const addBankTx2 = await contract.addBank("SBI bank","0xAb8483F64d9C6d1EcF9b849Ae677dD3315835cb2","2");
        console.log("Adding Bank 2");
        await addBankTx2.wait();

        expect(await contract.getBanksCount()).to.equal(2);

        // add Ram as a customer
        const addCustomerTx = await contract.addCustomer("Ram","Ram's data is here");
        console.log("Adding Customer 1");
        await addCustomerTx.wait();

        expect(await contract.getCustomersCount()).to.equal(1);

        // add Shyam as a customer
        const addCustomerTx2 = await contract.addCustomer("Shyam","Shyam's data is here");
        console.log("Adding Customer 2");
        await addCustomerTx2.wait();

        expect(await contract.getCustomersCount()).to.equal(2);


        // check initial Vote count for Ram
        console.log("Initial upVoteCustomerTx");

        expect(await contract.getCustomersDownVotes("Ram")).to.equal(0);

        // upvote Ram
        const upVoteCustomerTx = await contract.upVoteCustomer("Ram");
        console.log("upVoteCustomerTx");
        await upVoteCustomerTx.wait();

        expect(await contract.getCustomersUpVotes("Ram")).to.equal(1);
        
        // downvote Shyam
        const downVoteCustomerTx = await contract.downVoteCustomer("Shyam");
        console.log("downVoteCustomerTx");
        await downVoteCustomerTx.wait();  

        expect(await contract.getCustomersDownVotes("Shyam")).to.equal(1);

        // Up vote Ram again
        const upVoteCustomerTx2 = await contract.upVoteCustomer("Ram");
        console.log("upVoteCustomerTx");
        await upVoteCustomerTx2.wait();
        
        expect(await contract.getCustomersUpVotes("Ram")).to.equal(2);
        


    });


    
});